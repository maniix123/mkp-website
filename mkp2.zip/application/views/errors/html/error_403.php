<div class="content-wrapper">
	<section class="content">
		<div class="box box-danger">
			<div class="box-body text-center">
				<h1 style="font-size: 150px;">404</h1>
				<h4 style="font-size: 70px"><i class="fa fa-info-circle text-danger"></i> PAGE NOT FOUND</h4>
				<h1 style="margin-top: 50px;">Congrats, you found this page.</h1>
				<h3>Contact the <a href="<?= base_url() .'member/view/333' ?>">Website administrator</a> if you're experiencing problems with the website</h3>
				<small><i>Keep finding the secret page</i></small>
				<p><small><i>If you can..<br> I dare you..</i></small></p>
			</div>
		</div>
	</section>
</div>
<?php include FCPATH .'application\views\admin\admin-templates\footer.php'; ?>
</div>
<script src="<?php echo base_url() ?>adminlte/dist/plugins/jquery/jquery.min.js"></script>
<script src="<?php echo base_url() ?>adminlte/dist/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url() ?>adminlte/dist/js/app.js"></script>
</body>
</html>