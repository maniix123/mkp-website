<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-25 02:47:20 --> 404 Page Not Found: 
ERROR - 2018-12-25 03:15:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 03:16:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'from members' at line 4 - Invalid query: SELECT 
									members.id,
									password, 
									from members
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:01 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:08 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:42 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:18:59 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:08 --> Severity: error --> Exception: syntax error, unexpected ''<br>'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:19:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:31:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mkp\application\controllers\testcontroller.php:27) C:\xampp\htdocs\mkp\system\core\Common.php 570
ERROR - 2018-12-25 03:31:31 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 27
ERROR - 2018-12-25 03:34:40 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 30
ERROR - 2018-12-25 03:56:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '?' at line 1 - Invalid query: SELECT * FROM members WHERE username = ?
ERROR - 2018-12-25 04:05:23 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\mkp\application\models\User_model.php 102
ERROR - 2018-12-25 04:10:05 --> 404 Page Not Found: 
ERROR - 2018-12-25 04:20:49 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:49 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:49 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:50 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:50 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:50 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:50 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:50 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:50 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:51 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:51 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:51 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:51 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:51 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:52 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:52 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:52 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:52 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:52 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:52 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:52 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:53 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:53 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:53 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:53 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:53 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:54 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:54 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:54 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:54 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:54 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:55 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:55 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:55 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:55 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:55 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:55 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:56 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:56 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:56 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:56 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:56 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:56 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:57 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:57 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:57 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:57 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:57 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:58 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:58 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:58 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:58 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:58 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:59 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:59 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:59 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:20:59 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:00 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:00 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:00 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:00 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:00 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:00 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:01 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:01 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:01 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:01 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:01 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:02 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:21:02 --> Severity: Notice --> Undefined variable: new C:\xampp\htdocs\mkp\application\controllers\testcontroller.php 33
ERROR - 2018-12-25 04:39:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND
					members.batch_id = batch.id' at line 22 - Invalid query: SELECT 
					members.id, 
					FirstName, 
					LastName, 
					ContactNumber, 
					CurrentAddress, 
					PermanentAddress, 
					SlaveName, 
					username, 
					password, 
					status, 
					role, 
					AttyOrNot, 
					image, 
					batch_name, 
					year, 
					chapter, 
					batch.id as batch_id, 
					batch_president 
				from members, batch 
				WHERE 
					members.id =  AND
					members.batch_id = batch.id
ERROR - 2018-12-25 04:41:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND
					members.batch_id = batch.id' at line 22 - Invalid query: SELECT 
					members.id, 
					FirstName, 
					LastName, 
					ContactNumber, 
					CurrentAddress, 
					PermanentAddress, 
					SlaveName, 
					username, 
					password, 
					status, 
					role, 
					AttyOrNot, 
					image, 
					batch_name, 
					year, 
					chapter, 
					batch.id as batch_id, 
					batch_president 
				from members, batch 
				WHERE 
					members.id =  AND
					members.batch_id = batch.id
ERROR - 2018-12-25 04:43:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND
					members.batch_id = batch.id' at line 22 - Invalid query: SELECT 
					members.id, 
					FirstName, 
					LastName, 
					ContactNumber, 
					CurrentAddress, 
					PermanentAddress, 
					SlaveName, 
					username, 
					password, 
					status, 
					role, 
					AttyOrNot, 
					image, 
					batch_name, 
					year, 
					chapter, 
					batch.id as batch_id, 
					batch_president 
				from members, batch 
				WHERE 
					members.id =  AND
					members.batch_id = batch.id
ERROR - 2018-12-25 04:46:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND
					members.batch_id = batch.id' at line 22 - Invalid query: SELECT 
					members.id, 
					FirstName, 
					LastName, 
					ContactNumber, 
					CurrentAddress, 
					PermanentAddress, 
					SlaveName, 
					username, 
					password, 
					status, 
					role, 
					AttyOrNot, 
					image, 
					batch_name, 
					year, 
					chapter, 
					batch.id as batch_id, 
					batch_president 
				from members, batch 
				WHERE 
					members.id =  AND
					members.batch_id = batch.id
ERROR - 2018-12-25 04:51:43 --> Severity: error --> Exception: Call to undefined function checkAccount() C:\xampp\htdocs\mkp\application\models\User_model.php 20
ERROR - 2018-12-25 04:53:22 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\mkp\application\models\User_model.php 41
ERROR - 2018-12-25 04:58:32 --> Severity: Notice --> Undefined property: stdClass::$password C:\xampp\htdocs\mkp\application\views\admin\editprofile.php 170
ERROR - 2018-12-25 05:53:37 --> Severity: Notice --> Undefined property: stdClass::$password C:\xampp\htdocs\mkp\application\views\admin\editprofile.php 170
ERROR - 2018-12-25 05:54:24 --> Severity: Notice --> Undefined property: stdClass::$password C:\xampp\htdocs\mkp\application\views\admin\editprofile.php 170
ERROR - 2018-12-25 06:16:13 --> Could not find the language line "form_validation_check_username"
ERROR - 2018-12-25 06:16:41 --> Could not find the language line "form_validation_check_username"
ERROR - 2018-12-25 06:18:27 --> Could not find the language line "form_validation_check_username"
ERROR - 2018-12-25 06:18:42 --> Could not find the language line "form_validation_check_username"
ERROR - 2018-12-25 06:19:36 --> Could not find the language line "form_validation_check_username"
ERROR - 2018-12-25 06:20:29 --> Could not find the language line "form_validation_check_username"
ERROR - 2018-12-25 06:22:15 --> Could not find the language line "form_validation_call_back_check_username"
ERROR - 2018-12-25 06:23:07 --> Could not find the language line "form_validation_check_username"
ERROR - 2018-12-25 06:25:18 --> Could not find the language line "form_validation_check_username"
ERROR - 2018-12-25 06:26:42 --> Could not find the language line "form_validation_check_username"
ERROR - 2018-12-25 06:27:05 --> Could not find the language line "form_validation_check_username"
ERROR - 2018-12-25 06:29:18 --> Could not find the language line "form_validation_check_username"
ERROR - 2018-12-25 06:30:21 --> Could not find the language line "form_validation_check_username"
ERROR - 2018-12-25 06:37:21 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting ')' C:\xampp\htdocs\mkp\application\models\User_model.php 349
ERROR - 2018-12-25 06:37:30 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\mkp\application\models\User_model.php 347
ERROR - 2018-12-25 06:42:37 --> Severity: error --> Exception: Call to undefined method User_model::editMember() C:\xampp\htdocs\mkp\application\models\User_model.php 352
ERROR - 2018-12-25 06:43:35 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\mkp\application\models\User_model.php 353
ERROR - 2018-12-25 06:43:36 --> 404 Page Not Found: Mkp/member
ERROR - 2018-12-25 06:43:36 --> Severity: error --> Exception: Call to undefined function base_url() C:\xampp\htdocs\mkp\application\views\errors\html\error_404.php 14
ERROR - 2018-12-25 06:43:36 --> 404 Page Not Found: Mkp/member
ERROR - 2018-12-25 06:43:36 --> Severity: error --> Exception: Call to undefined function base_url() C:\xampp\htdocs\mkp\application\views\errors\html\error_404.php 14
ERROR - 2018-12-25 06:43:53 --> 404 Page Not Found: Mkp/member
ERROR - 2018-12-25 06:43:53 --> Severity: error --> Exception: Call to undefined function base_url() C:\xampp\htdocs\mkp\application\views\errors\html\error_404.php 14
ERROR - 2018-12-25 06:43:53 --> 404 Page Not Found: Mkp/member
ERROR - 2018-12-25 06:43:53 --> Severity: error --> Exception: Call to undefined function base_url() C:\xampp\htdocs\mkp\application\views\errors\html\error_404.php 14
ERROR - 2018-12-25 07:42:28 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\mkp\application\controllers\admincontroller.php 325
ERROR - 2018-12-25 07:42:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND
					members.batch_id = batch.id' at line 22 - Invalid query: SELECT 
					members.id, 
					FirstName, 
					LastName, 
					ContactNumber, 
					CurrentAddress, 
					PermanentAddress, 
					SlaveName, 
					username, 
					visible, 
					status, 
					role, 
					AttyOrNot, 
					image, 
					batch_name, 
					year, 
					chapter, 
					batch.id as batch_id, 
					batch_president 
				from members, batch 
				WHERE 
					members.id =  AND
					members.batch_id = batch.id
ERROR - 2018-12-25 08:00:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\mkp\application\controllers\admincontroller.php 312
ERROR - 2018-12-25 08:14:04 --> Query error: Unknown column 'usernamedwawdaada' in 'where clause' - Invalid query: SELECT *
FROM `members`
WHERE `usernamedwawdaada` = 'Saddam'
 LIMIT 1
ERROR - 2018-12-25 08:14:40 --> Query error: Unknown column 'imgdwwd' in 'where clause' - Invalid query: SELECT *
FROM `members`
WHERE `imgdwwd` = 'cairoden'
 LIMIT 1
ERROR - 2018-12-25 08:17:56 --> Query error: Unknown column 'usernamedwadad' in 'where clause' - Invalid query: SELECT *
FROM `members`
WHERE `usernamedwadad` = 'Saddam'
 LIMIT 1
ERROR - 2018-12-25 08:18:10 --> Query error: Unknown column 'oten' in 'where clause' - Invalid query: SELECT *
FROM `members`
WHERE `oten` = 'cairoden'
 LIMIT 1
ERROR - 2018-12-25 08:19:45 --> Severity: error --> Exception: Too few arguments to function CI_DB_driver::query(), 0 passed in C:\xampp\htdocs\mkp\application\controllers\admincontroller.php on line 314 and at least 1 expected C:\xampp\htdocs\mkp\system\database\DB_driver.php 608
ERROR - 2018-12-25 08:24:59 --> Unable to load the requested class: Database
ERROR - 2018-12-25 08:25:23 --> Unable to load the requested class: Database
ERROR - 2018-12-25 08:25:24 --> Unable to load the requested class: Database
ERROR - 2018-12-25 08:25:26 --> Unable to load the requested class: Database
ERROR - 2018-12-25 08:26:52 --> Severity: Notice --> Undefined property: admincontroller::$db C:\xampp\htdocs\mkp\system\core\Model.php 73
ERROR - 2018-12-25 08:26:52 --> Severity: error --> Exception: Call to a member function query() on null C:\xampp\htdocs\mkp\application\models\User_model.php 298
ERROR - 2018-12-25 08:27:48 --> Query error: Unknown column 'fuckingpieceofshit' in 'where clause' - Invalid query: SELECT *
FROM `members`
WHERE `fuckingpieceofshit` = 'abdaniehdwa'
 LIMIT 1
