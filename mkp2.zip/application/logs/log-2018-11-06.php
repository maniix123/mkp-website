<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-06 14:49:04 --> 404 Page Not Found: Member/blog
ERROR - 2018-11-06 14:49:05 --> Severity: error --> Exception: Call to undefined function base_url() C:\xampp\htdocs\mkp\application\views\errors\html\error_404.php 14
ERROR - 2018-11-06 14:49:09 --> 404 Page Not Found: Member/blog
ERROR - 2018-11-06 14:49:09 --> Severity: error --> Exception: Call to undefined function base_url() C:\xampp\htdocs\mkp\application\views\errors\html\error_404.php 14
