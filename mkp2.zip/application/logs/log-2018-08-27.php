<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-27 08:18:54 --> 404 Page Not Found: Member/view
ERROR - 2018-08-27 08:18:55 --> Severity: error --> Exception: Call to undefined function base_url() C:\xampp\htdocs\mkp\application\views\errors\html\error_404.php 14
ERROR - 2018-08-27 08:18:55 --> 404 Page Not Found: Member/view
ERROR - 2018-08-27 08:18:55 --> Severity: error --> Exception: Call to undefined function base_url() C:\xampp\htdocs\mkp\application\views\errors\html\error_404.php 14
