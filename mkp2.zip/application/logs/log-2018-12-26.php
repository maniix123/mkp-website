<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-26 07:14:22 --> Query error: Unknown column 'usernamsse' in 'where clause' - Invalid query: SELECT *
FROM `members`
WHERE `usernamsse` = 'cairoden'
 LIMIT 1
ERROR - 2018-12-26 13:19:31 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\views\admin\add-member.php 87
ERROR - 2018-12-26 13:19:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\add-member.php 87
ERROR - 2018-12-26 13:19:31 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\views\admin\add-member.php 93
ERROR - 2018-12-26 13:19:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\add-member.php 93
ERROR - 2018-12-26 13:23:16 --> Severity: error --> Exception: Call to undefined method User_model::displayAddPage() C:\xampp\htdocs\mkp\application\models\User_model.php 168
ERROR - 2018-12-26 13:24:18 --> Severity: 4096 --> Object of class User_model could not be converted to string C:\xampp\htdocs\mkp\application\models\User_model.php 170
ERROR - 2018-12-26 13:50:56 --> Severity: Notice --> Undefined variable: member C:\xampp\htdocs\mkp\application\views\admin\add-member.php 53
ERROR - 2018-12-26 13:50:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\add-member.php 53
ERROR - 2018-12-26 15:13:47 --> Severity: Notice --> Undefined property: CI_Loader::$input C:\xampp\htdocs\mkp\application\config\form_validation.php 8
ERROR - 2018-12-26 15:13:47 --> Severity: error --> Exception: Call to a member function post() on null C:\xampp\htdocs\mkp\application\config\form_validation.php 8
ERROR - 2018-12-26 15:14:14 --> Severity: Notice --> Undefined property: CI_Loader::$input C:\xampp\htdocs\mkp\application\config\form_validation.php 8
ERROR - 2018-12-26 15:14:14 --> Severity: error --> Exception: Call to a member function post() on null C:\xampp\htdocs\mkp\application\config\form_validation.php 8
ERROR - 2018-12-26 15:14:16 --> Severity: Notice --> Undefined property: CI_Loader::$input C:\xampp\htdocs\mkp\application\config\form_validation.php 8
ERROR - 2018-12-26 15:14:16 --> Severity: error --> Exception: Call to a member function post() on null C:\xampp\htdocs\mkp\application\config\form_validation.php 8
ERROR - 2018-12-26 15:15:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\mkp\application\config\form_validation.php 8
ERROR - 2018-12-26 15:15:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\mkp\application\config\form_validation.php 8
