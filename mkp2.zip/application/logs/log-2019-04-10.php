<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-10 14:43:47 --> Severity: Notice --> Undefined property: stdClass::$password C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 49
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 20
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 20
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 27
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 27
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 31
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 31
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 41
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 41
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 45
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 45
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 49
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 49
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 62
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 62
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 62
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 62
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 62
ERROR - 2019-04-10 14:46:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 62
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 20
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 20
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 27
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 27
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 31
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 31
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 41
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 41
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 45
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 45
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 49
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 49
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 57
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 62
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 62
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 62
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 62
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 62
ERROR - 2019-04-10 14:47:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mkp\application\views\admin\deletemember.php 62
