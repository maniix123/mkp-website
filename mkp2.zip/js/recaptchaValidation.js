function recaptchaCallback(){
	let recaptcha = document.getElementById('recaptcha');
	let contactNumber = document.getElementById('contactNumber');
	window.setTimeout(() => {
		recaptcha.classList.add('disappear');
		contactNumber.style.display = 'block';
	}, 700)
	window.setTimeout(() => {
		recaptcha.style.display = 'none';
	}, 600);
}